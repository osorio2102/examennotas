package entidades;
 
 public class NotaMusical {
     private Nota nota;
     private Figura figura;
     private int octava;
 
     public NotaMusical(Nota nota, Figura figura, int octava) {
         this.nota = nota;
         this.figura = figura;
         this.octava = octava;
     }
 
     public NotaMusical() {
     }
 
     // Getters y Setters
     public Nota getNota() {
         return nota;
     }
 
     public void setNota(Nota nota) {
         this.nota = nota;
     }
 
     public Figura getFigura() {
         return figura;
     }
 
     public void setFigura(Figura figura) {
         this.figura = figura;
     }
 
     public int getOctava() {
         return octava;
     }
 
     public void setOctava(int octava) {
         this.octava = octava;
     }
 
     public String toString() {
         return nota.name() + "," + figura.name() + "," + octava;
     }
 
     
     public static NotaMusical fromString(String data) {
         String[] parts = data.split(",");
         NotaMusical notaMusical = new NotaMusical();
         notaMusical.setNota(Nota.valueOf(parts[0]));
         notaMusical.setFigura(Figura.valueOf(parts[1]));
         notaMusical.setOctava(Integer.parseInt(parts[2]));
         return notaMusical;
     }
 }
package entidades;

public enum Nota {
    DO, DO_SOSTENIDO, RE, RE_SOSTENIDO, MI, FA, FA_SOSTENIDO, SOL, SOL_SOSTENIDO, LA, LA_SOSTENIDO, SI,
    } //ibamos a poner más notas musicales pero no sonaban tan bien para la canción del binomio de oro teacher, se cancela 
    

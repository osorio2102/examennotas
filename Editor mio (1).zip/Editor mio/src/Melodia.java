import java.util.ArrayList;
 import java.util.List;
 import javax.swing.JTable;
 import javax.swing.table.DefaultTableModel;
 import com.fasterxml.jackson.core.type.TypeReference;

import entidades.Figura;
import entidades.Nota;
import entidades.NotaMusical;
 import java.io.IOException;
 import java.nio.file.Files;
 import java.nio.file.Paths;
 import java.nio.charset.StandardCharsets;

 public class Melodia {

     private Nodo cabeza;

     public Melodia() {
         cabeza = null;
     }

     public void agregar(Nodo n) {
         if (n != null) {
             if (cabeza == null) {
                 cabeza = n;
             } else {
                 Nodo apuntador = cabeza;
                 while (apuntador.siguiente != null) {
                     apuntador = apuntador.siguiente;
                 }
                 apuntador.siguiente = n;
             }
             n.siguiente = null;
         }
     }

     public void eliminar(Nodo n) {
         if (n != null && cabeza != null) {
             // Buscar el nodo
             boolean encontrado = false;
             Nodo apuntador = cabeza;
             Nodo anterior = null;
             while (apuntador != null && !encontrado) {
                 if (apuntador == n) {
                     encontrado = true;
                 } else {
                     anterior = apuntador;
                     apuntador = apuntador.siguiente;
                 }
             }
             if (encontrado) {
                 if (anterior == null) {
                     cabeza = apuntador.siguiente;
                 } else {
                     anterior.siguiente = apuntador.siguiente;
                 }
             }
         }
     }

     public int obtenerLongitud() {
         int totalNodos = 0;
         Nodo apuntador = cabeza;
         while (apuntador != null) {
             totalNodos++;
             apuntador = apuntador.siguiente;
         }
         return totalNodos;
     }

     public Nodo obtenerNodo(int posicion) {
         int p = 0;
         Nodo apuntador = cabeza;
         while (apuntador != null && p != posicion) {
             apuntador = apuntador.siguiente;
             p++;
         }
         if (apuntador != null && p == posicion) {
             return apuntador;
         } else {
             return null;
         }
     }

     public void guardarJSON(String nombreArchivo) {
         StringBuilder json = new StringBuilder("[");
         Nodo actual = cabeza;
         while (actual != null) {
             json.append("\"").append(actual.getNotaMusical().toString()).append("\"");
             if (actual.siguiente != null) {
                 json.append(",");
             }
             actual = actual.siguiente;
         }
         json.append("]");

         try {
             Files.write(Paths.get(nombreArchivo), json.toString().getBytes(StandardCharsets.UTF_8));
         } catch (IOException e) {
             e.printStackTrace();
         }
     }

     public void desdeJSON(String nombreArchivo) {
         cabeza = null;
         try {
             String json = new String(Files.readAllBytes(Paths.get(nombreArchivo)), StandardCharsets.UTF_8);
             json = json.replace("[", "").replace("]", "").replace("\"", "");
             String[] notasData = json.split(",");
             for (int i = 0; i < notasData.length; i += 3) {
                 Nota nota = Nota.valueOf(notasData[i]);
                 Figura figura = Figura.valueOf(notasData[i + 1]);
                 int octava = Integer.parseInt(notasData[i + 2]);
                 agregar(new Nodo(new NotaMusical(nota, figura, octava)));
             }
         } catch (IOException e) {
             e.printStackTrace();
         }
     }

     public static String[] encabezados = new String[] { "Nota", "Figura", "Octava" };

     public void mostrar(JTable tbl) {
         int filas = obtenerLongitud();
         String[][] datos = new String[filas][3];
         Nodo apuntador = cabeza;
         filas = 0;
         while (apuntador != null) {
             datos[filas][0] = apuntador.getNotaMusical().getNota().toString();
             datos[filas][1] = apuntador.getNotaMusical().getFigura().toString();
             datos[filas][2] = String.valueOf(apuntador.getNotaMusical().getOctava());
             apuntador = apuntador.siguiente;
             filas++;
         }
         DefaultTableModel dtm = new DefaultTableModel(datos, encabezados);
         tbl.setModel(dtm);
     }

     public void reproducirMelodia() {
         Nodo apuntador = cabeza;
         while (apuntador != null) {
             ReproductorAudioMIDI.reproducirNota(apuntador.getNotaMusical());
             apuntador = apuntador.siguiente;
         }
     }
 }